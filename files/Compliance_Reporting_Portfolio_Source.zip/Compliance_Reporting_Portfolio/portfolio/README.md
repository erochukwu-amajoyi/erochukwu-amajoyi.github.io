# Compliance reporting and data-quality monitor

Personal portfolio demonstration by Erochukwu Amajoyi. All records are fictional; this is not Wren data or a commissioned project. Developed with AI assistance, with executable tests and independent calculation checks documented below.

## Business brief

A hypothetical operations/compliance team needs repeatable reporting on new cases, closures, overdue cases and backlog. Its manual workflow is: receive extract, copy and clean rows, calculate metrics, assemble a report, then distribute it. Risks include duplicate keys, inconsistent dates, stale extracts and a failed run overwriting the last usable report.

The prototype workflow is: validate the extract -> check freshness -> load an isolated MySQL database -> calculate metrics -> independently reconcile outputs -> publish a latest-success reference. A run log distinguishes invalid, stale and late reports. Distribution and scheduling are proposed next steps, not implemented capabilities.

### Questions to agree with stakeholders before production

- Who owns each measure and acts on overdue cases?
- Should SLAs use calendar or working days? How should paused/reopened cases behave?
- What extract-completeness signal is available, beyond row count and schema checks?
- What are the reporting deadline, timezone, maximum source age and escalation route?
- Is a late valid report preferable to no report, and how should users see that warning?
- What access, retention and privacy controls apply to the real source?

These are proposed discovery questions; no stakeholder interviews are claimed.

## Data and definitions

Fixed seed 29788 generates 1,200 cases from 29 June through 20 September 2026. Three departments, four categories and three priorities. One record per case; no pauses, reopening, deletions or reassignment history. Timestamps are UTC; deadlines use calendar days. `2026-09-21 00:00:00` is the exclusive reporting cutoff.

| Field | Meaning / constraint |
|---|---|
| case_id | Unique non-empty case key |
| department_id | Foreign key: 1 Customer Services, 2 Warehouse, 3 Installation |
| category | Missing evidence, Record mismatch, Process deviation or Late review |
| priority | High, Medium or Low; generated SLA 3, 7 or 14 days respectively |
| opened_at | Creation time within the extract's coverage |
| due_at | Deadline; must not precede creation |
| closed_at | Resolution time, or blank if still open at the snapshot |

Open backlog = opened before cutoff and not closed before cutoff. Overdue open = open backlog with due time before cutoff. On-time due-cohort rate = cases due before cutoff and closed at/before deadline divided by **all** cases due before cutoff. This includes due cases still open in the denominator. Resolution time = elapsed calendar days, averaged over closed cases only.

Period starts are inclusive and ends exclusive. Backlog is a stock at period end, not a count to sum across periods. Daily and weekly periods are complete; June and September monthly periods are partial. Comparisons must respect this coverage. The fixture intentionally makes some Warehouse resolutions slower after 10 August; this is not evidence of a real causal relationship.

## Verified findings

- 1,200 cases; 934 closed; 266 open; 157 overdue open.
- 365 of 1,076 due cases closed on time: **33.9%**.
- 157 / 266 open cases overdue: **59.0%**.
- Mean resolution: **10.191 days**, displayed as 10.2.
- Warehouse: 341 cases, 99 open, 56 overdue. Installation: 359 / 79 / 52. Customer Services: 500 / 88 / 49.
- 84 daily + 12 weekly + 4 monthly = **100 reconciled period rows**.

Recommended first action: review the oldest overdue cases with department leads and investigate case mix, ownership and capacity. No savings or production impact are claimed.

## Files

- `generate_data.py`: deterministic synthetic-data generator; manifest includes actual extraction timestamp.
- `reporting.py`: validation, scenario controls, MySQL execution, independent reconciliation and atomic latest-success reference.
- `test_reporting.py`: 19 unit tests, including invalid keys/dates, cutoff boundaries, due-cohort denominator, freshness/deadline boundaries and pointer preservation.
- `sql/`: schema and metrics, department, period and overdue-case queries.
- `data/`: clean and deliberately invalid CSV fixtures, departments and source manifest.
- `evidence/`: MySQL CSV outputs, issues, run log, latest-success JSON and workbook input payload.
- `Compliance_Reporting_Workbook.xlsx`: report, Pivot, filterable Cases and Runs tabs (when included in the downloadable package).

## Reproduce the data and SQL checks

Requires Python 3.10+ (standard library only) and Docker with the official MySQL image. Use this isolated demonstration container, **never a production database**. It exposes no ports and has no network. Its data directory is temporary and disappears when stopped; source CSV and SQL files remain on your machine. The empty root password is suitable only for this network-isolated throwaway fixture, never a real service.

From this folder:

```sh
python3 generate_data.py
python3 -m unittest discover -s . -v
docker run --name ero-wren-mysql-20260927 --rm --network none --memory 768m --cpus 1 --tmpfs /var/lib/mysql:rw,size=384m -e MYSQL_ALLOW_EMPTY_PASSWORD=yes -d mysql:8.4 --skip-log-bin
docker exec ero-wren-mysql-20260927 mysqladmin -uroot ping
python3 reporting.py
docker stop ero-wren-mysql-20260927
```

Run the readiness check again if initial database startup is not complete. If that container name already exists, inspect it rather than replacing it. `reporting.py` refreshes only the dedicated `compliance_portfolio` database inside the exact named demo container. Python runner results are validated before promotion. The tested version was MySQL 8.4.11.

### Scenarios and evidence interpretation

Four controlled scenarios use one extract timestamp and simulated evaluation offsets. The log also records each **actual execution timestamp**. These are not four scheduled deliveries or historical service availability measurements.

| Scenario | Input / accepted | Data issues | Outcome |
|---|---|---|---|
| Clean, source age 5 min | 1,200 / 1,200 | 0 | ON_TIME; published |
| Dirty, source age 10 min | 1,201 / 1,194 | 7 | BLOCKED_DATA; latest report unchanged |
| Stale, source age 60 min | 1,200 / 1,200 | 0 | BLOCKED_STALE; latest report unchanged |
| Late, source age 25 min | 1,200 / 1,200 | 0 | LATE; published with warning status |

Maximum source age is 30 minutes. Scenario deadline is 20 minutes after extraction. Future-dated sources are also blocked (unit tested). Both duplicate occurrences are rejected in the dirty fixture. These checks are a defined rule set, not proof that every conceivable defect is detected.

## Excel use and refresh

Start on Reporting. Filter Cases to see individual records; filters deliberately do not alter the overall headline metrics. Pivot contains a genuine native PivotTable: Case ID count by Department; Category is also available in the field list. Use PivotTable Refresh after editing its source values.

This is a reviewed snapshot, not a live-connected workbook. To refresh the report, rerun the data/SQL process, then rebuild the workbook from the updated evidence. The build source is supplied separately with the package, and requires the `@oai/artifact-tool` runtime used for this project. Python-only evidence reproduction does not require that package. The workbook can be opened and explored without any coding dependencies.

Rebuild for a changed source row count: formulas and Pivot source range are bounded to the generated extract. Do not merely append rows and assume all summary ranges expanded. The snapshot cutoff belongs to the build; changing it alone does not change the static monthly SQL outputs or source coverage. Blue register values indicate input fields; derived flag columns are formulas.

Verification: native Pivot cache has 1,200 records; native chart and table structures were checked. Headline KPIs and 12 weekly rows reconcile. An independent LibreOffice recalculation with formula caches removed confirmed that closing one open case reduces backlog from 266 to 265. Native Excel Desktop refresh and Pivot field rearrangement are **not yet user-tested**. The renderer's stale dependency cache and missing chart caches required independent recalculation/export-cache checks; no Excel Desktop test is claimed.

Before presenting: open in Excel, use Refresh All, filter overdue cases, rearrange the Pivot by Category, and explain the denominator and late-run policy. Desktop Excel may render styling differently. Keep the reviewed original and practise on a copy.

## Production boundary

No real credentials, source integration, scheduler, Power Automate flow, email delivery, alert receiver, production database or SLA is deployed. The runner currently executes demonstration scenarios, not a production command-line job accepting arbitrary extracts. Adding a scheduler alone would not make it production-ready. Required follow-up includes authorised sources, least-privilege access, parameterised periods, completeness checks, failure/retry policy, idempotency, retention, delivery acknowledgements and alert ownership.
