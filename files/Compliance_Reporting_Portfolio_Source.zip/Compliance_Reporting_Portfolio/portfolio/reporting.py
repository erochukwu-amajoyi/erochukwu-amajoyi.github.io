"""Validate an extract, query local MySQL and publish a traceable report.

No scheduler or email transport is installed. Scenario runs demonstrate controls.
"""
import csv
import hashlib
import io
import json
import subprocess
import time
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CONTAINER = 'ero-wren-mysql-20260927'
CUTOFF = datetime(2026, 9, 21)
START = datetime(2026, 6, 29)
DEPTS = {1: 'Customer Services', 2: 'Warehouse', 3: 'Installation'}

def read_rows(path):
    with Path(path).open(newline='') as f:
        return list(csv.DictReader(f))

def validate(rows, cutoff=CUTOFF):
    issues, clean = [], []
    if not rows:
        return [], [{'csv_row': 0, 'case_id': '', 'issue': 'empty_extract'}]
    ids = Counter(r.get('case_id', '') for r in rows)
    for n, r in enumerate(rows, 2):
        errs = []
        if not r.get('case_id') or ids[r.get('case_id', '')] != 1: errs.append('missing_or_duplicate_key')
        if str(r.get('department_id')) not in [str(d) for d in DEPTS]: errs.append('unknown_department')
        if r.get('category') not in ['Missing evidence', 'Record mismatch', 'Process deviation', 'Late review']: errs.append('invalid_category')
        if r.get('priority') not in ['High', 'Medium', 'Low']: errs.append('invalid_priority')
        parsed = dict(r)
        for field in ['opened_at', 'due_at', 'closed_at']:
            try:
                parsed[field] = datetime.fromisoformat(r[field]) if r.get(field) else None
                if field != 'closed_at' and parsed[field] is None: raise ValueError()
                if parsed[field] and parsed[field].tzinfo is not None: raise ValueError()
            except (ValueError, TypeError):
                parsed[field] = None; errs.append('invalid_' + field)
        opened, due, closed = (parsed[k] for k in ['opened_at', 'due_at', 'closed_at'])
        if opened and not START <= opened < cutoff: errs.append('opened_outside_coverage')
        if opened and due and due < opened: errs.append('due_before_open')
        if opened and closed and closed < opened: errs.append('closed_before_open')
        if closed and closed >= cutoff: errs.append('closed_outside_snapshot')
        for error in errs: issues.append({'csv_row': n, 'case_id': r.get('case_id', ''), 'issue': error})
        if not errs:
            parsed['department_id'] = int(parsed['department_id']); clean.append(parsed)
    return clean, issues

def periods():
    result = []
    for grain, step in [('daily', 1), ('weekly', 7)]:
        d = START
        while d < CUTOFF:
            end = min(d + timedelta(days=step), CUTOFF)
            result.append((grain, d, end, 0)); d = end
    d = datetime(2026, 6, 1)
    while d < CUTOFF:
        nxt = datetime(d.year + (d.month == 12), d.month % 12 + 1, 1)
        result.append(('monthly', max(d, START), min(nxt, CUTOFF), int(d < START or nxt > CUTOFF)))
        d = nxt
    return result

def independent_metrics(clean):
    closed = [r for r in clean if r['closed_at'] is not None]
    due = [r for r in clean if r['due_at'] < CUTOFF]
    return dict(total_cases=len(clean), open_cases=len(clean)-len(closed),
        overdue_open_cases=sum(r['closed_at'] is None for r in due), due_cases=len(due),
        ontime_due_cases=sum(r['closed_at'] is not None and r['closed_at'] <= r['due_at'] for r in due),
        closed_cases=len(closed), mean_resolution_days=round(sum((r['closed_at']-r['opened_at']).total_seconds()/86400 for r in closed)/len(closed),4) if closed else None)

def mysql(sql, database=True):
    cmd = ['docker', 'exec', '-i', CONTAINER, 'mysql', '-uroot', '--batch', '--raw']
    if database: cmd.append('compliance_portfolio')
    proc = subprocess.run(cmd, input=sql, text=True, capture_output=True, timeout=60, check=True)
    return proc.stdout

def literal(value):
    if value is None or value == '': return 'NULL'
    if isinstance(value, (int, float)): return str(value)
    if isinstance(value, datetime): value = value.isoformat(' ')
    return "CONVERT(0x" + str(value).encode().hex() + " USING utf8mb4)"

def load_database(clean):
    mysql((ROOT/'sql/schema.sql').read_text(), False)
    statements = ['START TRANSACTION;', 'DELETE FROM cases;', 'DELETE FROM departments;', 'DELETE FROM reporting_periods;']
    statements.append('INSERT INTO departments VALUES ' + ','.join('('+literal(k)+','+literal(v)+')' for k,v in DEPTS.items()) + ';')
    fields = ['case_id','department_id','category','priority','opened_at','due_at','closed_at']
    for start in range(0, len(clean), 200):
        statements.append('INSERT INTO cases VALUES ' + ','.join('('+','.join(literal(r[k]) for k in fields)+')' for r in clean[start:start+200]) + ';')
    statements.append('INSERT INTO reporting_periods VALUES ' + ','.join('('+','.join(literal(v) for v in row)+')' for row in periods()) + ';COMMIT;')
    mysql('\n'.join(statements))

def query(name):
    raw = mysql("SET @cutoff = '2026-09-21 00:00:00';\n" + (ROOT/'sql'/f'{name}.sql').read_text())
    return list(csv.DictReader(io.StringIO(raw), delimiter='\t'))

def control_status(issues, extracted, evaluation_time, deadline, max_age_minutes=30):
    age = (evaluation_time-extracted).total_seconds()/60
    if issues: return 'BLOCKED_DATA'
    if age < 0: return 'BLOCKED_FUTURE_SOURCE'
    if age > max_age_minutes: return 'BLOCKED_STALE'
    return 'LATE' if evaluation_time > deadline else 'ON_TIME'

def publish_latest(output, report, status):
    if status not in ['ON_TIME','LATE']: return False
    tmp = Path(output)/'latest.tmp'
    tmp.write_text(json.dumps(report, indent=2))
    tmp.replace(Path(output)/'latest.json')
    return True

def run_scenarios():
    out = ROOT/'evidence'; out.mkdir(exist_ok=True)
    manifest = json.loads((ROOT/'data/manifest.json').read_text())
    baseline = datetime.fromisoformat(manifest['extract_created_at_utc'])
    deadline = baseline + timedelta(minutes=20)
    attempts = []
    outputs = {}
    for scenario, file, offset in [('clean','cases.csv',5),('dirty','cases_dirty.csv',10),('stale','cases.csv',60),('late','cases.csv',25)]:
        t = time.perf_counter()
        rows = read_rows(ROOT/'data'/file); clean, issues = validate(rows)
        evaluated = baseline + timedelta(minutes=offset)
        status = control_status(issues, baseline, evaluated, deadline)
        before = (out/'latest.json').read_bytes() if (out/'latest.json').exists() else None
        version = ''
        if status in ['ON_TIME','LATE']:
            load_database(clean)
            version = mysql('SELECT VERSION();').strip().splitlines()[-1]
            outputs = {name: query(name) for name in ['metrics','department_summary','period_summary','overdue_cases']}
            expected = independent_metrics(clean)
            actual = outputs['metrics'][0]
            for key, value in expected.items():
                assert value is None and actual[key]=='NULL' or abs(float(actual[key])-value) < .00011, (key,value,actual[key])
            for rec in outputs['department_summary']:
                subset=[r for r in clean if DEPTS[r['department_id']]==rec['department']]
                expected_dept=independent_metrics(subset)
                assert all(int(rec[k])==expected_dept[k] for k in ['total_cases','open_cases','overdue_open_cases'])
            assert {r['case_id'] for r in outputs['overdue_cases']} == {r['case_id'] for r in clean if r['closed_at'] is None and r['due_at'] < CUTOFF}
            for rec in outputs['period_summary']:
                lo=datetime.fromisoformat(rec['period_start']); hi=datetime.fromisoformat(rec['period_end_exclusive'])
                expected_period={
                    'opened_cases':sum(lo <= r['opened_at'] < hi for r in clean),
                    'closed_cases':sum(r['closed_at'] is not None and lo <= r['closed_at'] < hi for r in clean),
                    'closing_backlog':sum(r['opened_at'] < hi and (r['closed_at'] is None or r['closed_at'] >= hi) for r in clean),
                    'overdue_backlog':sum(r['opened_at'] < hi and r['due_at'] < hi and (r['closed_at'] is None or r['closed_at'] >= hi) for r in clean)}
                assert all(int(rec[k])==v for k,v in expected_period.items()), (rec,expected_period)
            report={'scenario':scenario,'metrics':expected,'mysql_version':version,'source_sha256':hashlib.sha256((ROOT/'data'/file).read_bytes()).hexdigest()}
            assert publish_latest(out,report,status)
        else:
            assert not publish_latest(out,{},status)
            after=(out/'latest.json').read_bytes() if (out/'latest.json').exists() else None
            assert before==after
        attempt={'scenario':scenario,'executed_at_utc':datetime.now(timezone.utc).isoformat(),
            'scenario_evaluation_utc':evaluated.isoformat(),'scenario_deadline_utc':deadline.isoformat(),
            'source_age_minutes':offset,'status':status,'input_rows':len(rows),'accepted_rows':len(clean),
            'issue_count':len(issues),'duration_ms':round((time.perf_counter()-t)*1000,1),
            'published':status in ['ON_TIME','LATE'],'mysql_version':version,
            'note':'Controlled scenario, not a historical scheduled run or email delivery.'}
        attempts.append(attempt)
        (out/f'{scenario}_issues.json').write_text(json.dumps(issues,indent=2))
    for name,records in outputs.items():
        with (out/f'{name}.csv').open('w', newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
    (out/'runs.json').write_text(json.dumps(attempts,indent=2))
    clean,_=validate(read_rows(ROOT/'data/cases.csv'))
    payload={'manifest':manifest,'metrics':independent_metrics(clean),'departments':DEPTS,
        'rows':[{k:v.isoformat(' ') if isinstance(v,datetime) else v for k,v in r.items()} for r in clean],
        'query_results':outputs,'runs':attempts}
    (out/'workbook_data.json').write_text(json.dumps(payload,indent=2))
    print(json.dumps({'metrics':payload['metrics'],'scenarios':attempts,'period_rows_checked':len(outputs['period_summary'])},indent=2))

if __name__=='__main__': run_scenarios()
