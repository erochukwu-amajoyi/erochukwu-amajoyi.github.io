"""Deterministic fictional data. No employer or personal records."""
import csv
import json
import random
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CUTOFF = datetime(2026, 9, 21)
START = datetime(2026, 6, 29)
DEPARTMENTS = {1: 'Customer Services', 2: 'Warehouse', 3: 'Installation'}
FIELDS = ['case_id', 'department_id', 'category', 'priority', 'opened_at', 'due_at', 'closed_at']

def generate():
    rng = random.Random(29788)
    rows = []
    for i in range(1200):
        opened = START + timedelta(days=rng.randrange(84), hours=rng.randrange(8, 17))
        department = rng.choices([1, 2, 3], [4, 3, 3])[0]
        priority = rng.choices(['High', 'Medium', 'Low'], [2, 5, 3])[0]
        due = opened + timedelta(days={'High': 3, 'Medium': 7, 'Low': 14}[priority])
        duration = rng.randint(1, 18) + (10 if department == 2 and opened >= datetime(2026, 8, 10) else 0)
        closed = opened + timedelta(days=duration, hours=rng.randrange(3))
        if rng.random() < .10 or closed >= CUTOFF:
            closed = None
        rows.append(dict(zip(FIELDS, [f'CASE-{i+1:05d}', department,
            rng.choice(['Missing evidence', 'Record mismatch', 'Process deviation', 'Late review']),
            priority, opened.isoformat(' '), due.isoformat(' '), closed.isoformat(' ') if closed else ''])))
    return rows

def main():
    folder = ROOT / 'data'
    folder.mkdir(exist_ok=True)
    rows = generate()
    for name, data in [('cases.csv', rows), ('cases_dirty.csv', [dict(r) for r in rows])]:
        if 'dirty' in name:
            data[0]['department_id'] = 99
            data[1]['opened_at'] = 'not-a-date'
            data[2]['due_at'] = '2026-01-01 09:00:00'
            data[3]['closed_at'] = '2026-01-01 09:00:00'
            data[4]['category'] = ''
            data.append(dict(data[10]))
        with (folder / name).open('w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=FIELDS); w.writeheader(); w.writerows(data)
    with (folder / 'departments.csv').open('w', newline='') as f:
        w = csv.writer(f); w.writerow(['department_id', 'department']); w.writerows(DEPARTMENTS.items())
    (folder / 'manifest.json').write_text(json.dumps({
        'source': 'Fictional operational exceptions generated with seed 29788',
        'extract_created_at_utc': datetime.now(timezone.utc).isoformat(),
        'coverage_start': START.isoformat(), 'coverage_end_exclusive': CUTOFF.isoformat(),
        'expected_clean_rows': len(rows),
        'assumptions': 'Calendar-day deadlines. One record per case. No reopenings. Warehouse delays deliberately increase after 10 August.'
    }, indent=2))
    print(f'Generated {len(rows)} clean and {len(rows)+1} intentionally dirty rows.')

if __name__ == '__main__':
    main()
