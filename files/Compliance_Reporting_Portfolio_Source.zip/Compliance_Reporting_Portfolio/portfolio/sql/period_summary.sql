-- Daily, weekly and monthly flows; do not sum closing backlogs across periods.
-- Partial months are labelled and must not be compared directly with full months.
SELECT p.grain, DATE(p.period_start) AS period_start, DATE(p.period_end) AS period_end_exclusive,
 p.partial_period,
 SUM(CASE WHEN c.opened_at >= p.period_start THEN 1 ELSE 0 END) AS opened_cases,
 SUM(CASE WHEN c.closed_at >= p.period_start AND c.closed_at < p.period_end THEN 1 ELSE 0 END) AS closed_cases,
 SUM(CASE WHEN c.case_id IS NOT NULL AND (c.closed_at IS NULL OR c.closed_at >= p.period_end) THEN 1 ELSE 0 END) AS closing_backlog,
 SUM(CASE WHEN c.due_at < p.period_end AND (c.closed_at IS NULL OR c.closed_at >= p.period_end) THEN 1 ELSE 0 END) AS overdue_backlog
FROM reporting_periods p
LEFT JOIN cases c ON c.opened_at < p.period_end
GROUP BY p.grain, p.period_start, p.period_end, p.partial_period
ORDER BY p.grain, p.period_start;
