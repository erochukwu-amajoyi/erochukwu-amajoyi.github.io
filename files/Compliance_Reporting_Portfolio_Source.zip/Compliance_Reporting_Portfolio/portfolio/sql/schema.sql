-- MySQL 8.4. Run only inside the isolated portfolio database.
CREATE DATABASE IF NOT EXISTS compliance_portfolio;
USE compliance_portfolio;
CREATE TABLE IF NOT EXISTS departments (
  department_id INT PRIMARY KEY,
  department VARCHAR(50) NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS cases (
  case_id VARCHAR(20) PRIMARY KEY,
  department_id INT NOT NULL,
  category VARCHAR(40) NOT NULL,
  priority VARCHAR(10) NOT NULL,
  opened_at DATETIME NOT NULL,
  due_at DATETIME NOT NULL,
  closed_at DATETIME NULL,
  FOREIGN KEY (department_id) REFERENCES departments(department_id),
  CHECK (due_at >= opened_at),
  CHECK (closed_at IS NULL OR closed_at >= opened_at),
  INDEX ix_opened (opened_at), INDEX ix_due (due_at)
);
CREATE TABLE IF NOT EXISTS reporting_periods (
  grain VARCHAR(10) NOT NULL,
  period_start DATETIME NOT NULL,
  period_end DATETIME NOT NULL,
  partial_period BOOLEAN NOT NULL,
  PRIMARY KEY (grain, period_start)
);
