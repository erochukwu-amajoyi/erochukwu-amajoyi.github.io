-- LEFT JOIN retains a department even if it has no eligible cases.
SELECT d.department, COUNT(c.case_id) AS total_cases,
 SUM(CASE WHEN c.case_id IS NOT NULL AND (c.closed_at IS NULL OR c.closed_at >= @cutoff) THEN 1 ELSE 0 END) AS open_cases,
 SUM(CASE WHEN c.due_at < @cutoff AND (c.closed_at IS NULL OR c.closed_at >= @cutoff) THEN 1 ELSE 0 END) AS overdue_open_cases
FROM departments d
LEFT JOIN cases c ON c.department_id = d.department_id AND c.opened_at < @cutoff
GROUP BY d.department_id, d.department ORDER BY overdue_open_cases DESC, d.department;
