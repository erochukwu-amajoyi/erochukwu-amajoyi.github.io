SELECT c.case_id, d.department, c.category, c.priority, c.opened_at, c.due_at,
 ROUND(TIMESTAMPDIFF(SECOND, c.due_at, @cutoff) / 86400.0, 2) AS overdue_days
FROM cases c JOIN departments d ON d.department_id = c.department_id
WHERE c.opened_at < @cutoff AND c.due_at < @cutoff
 AND (c.closed_at IS NULL OR c.closed_at >= @cutoff)
ORDER BY c.due_at, c.case_id;
