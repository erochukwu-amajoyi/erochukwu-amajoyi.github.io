import unittest
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from reporting import validate, independent_metrics, control_status, publish_latest, periods

class ReportingTests(unittest.TestCase):
    def row(self, **kw):
        row=dict(case_id='C1',department_id='1',category='Missing evidence',priority='High',opened_at='2026-07-01 09:00:00',due_at='2026-07-04 09:00:00',closed_at='')
        row.update(kw);return row
    def issue(self, key, **kw):
        clean,issues=validate([self.row(**kw)])
        self.assertFalse(clean);self.assertIn(key,[x['issue'] for x in issues])
    def test_clean_open(self):
        c,e=validate([self.row()]);self.assertEqual(len(c),1);self.assertFalse(e)
    def test_duplicate_both_rejected(self):
        c,e=validate([self.row(),self.row()]);self.assertFalse(c);self.assertEqual(len(e),2)
    def test_unknown_department(self): self.issue('unknown_department',department_id='99')
    def test_blank_category(self): self.issue('invalid_category',category='')
    def test_invalid_priority(self): self.issue('invalid_priority',priority='Urgent')
    def test_bad_date(self): self.issue('invalid_opened_at',opened_at='31/99/2026')
    def test_missing_due(self): self.issue('invalid_due_at',due_at='')
    def test_due_before_open(self): self.issue('due_before_open',due_at='2026-06-30 00:00:00')
    def test_closed_before_open(self): self.issue('closed_before_open',closed_at='2026-06-30 00:00:00')
    def test_exclusive_cutoff(self): self.issue('opened_outside_coverage',opened_at='2026-09-21 00:00:00',due_at='2026-09-22 00:00:00')
    def test_empty(self): self.assertEqual(validate([])[1][0]['issue'],'empty_extract')
    def test_exact_deadline_ontime(self):
        c,e=validate([self.row(closed_at='2026-07-04 09:00:00')]);self.assertEqual(independent_metrics(c)['ontime_due_cases'],1)
    def test_open_due_in_denominator(self):
        c,e=validate([self.row()]);m=independent_metrics(c);self.assertEqual(m['due_cases'],1);self.assertEqual(m['ontime_due_cases'],0)
    def test_future_due_not_overdue(self):
        c,e=validate([self.row(due_at='2026-09-22 00:00:00')]);self.assertEqual(independent_metrics(c)['overdue_open_cases'],0)
    def test_zero_resolution(self):
        c,e=validate([self.row(closed_at='2026-07-01 09:00:00')]);self.assertEqual(independent_metrics(c)['mean_resolution_days'],0)
    def test_periods(self):
        p=periods();self.assertEqual(sum(r[0]=='daily' for r in p),84);self.assertEqual(sum(r[0]=='weekly' for r in p),12);self.assertEqual(sum(r[0]=='monthly' for r in p),4)
        self.assertEqual(sum(r[3] for r in p),2)
    def test_control_boundaries(self):
        t=datetime(2026,9,27,tzinfo=timezone.utc);deadline=t+timedelta(minutes=20)
        for minutes,expected in [(-1,'BLOCKED_FUTURE_SOURCE'),(20,'ON_TIME'),(25,'LATE'),(30,'LATE'),(31,'BLOCKED_STALE')]:
            self.assertEqual(control_status([],t,t+timedelta(minutes=minutes),deadline),expected)
        self.assertEqual(control_status([{}],t,t+timedelta(minutes=1),deadline),'BLOCKED_DATA')
    def test_failed_run_preserves_latest(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertTrue(publish_latest(d,{'result':1},'ON_TIME'))
            before=(Path(d)/'latest.json').read_bytes()
            self.assertFalse(publish_latest(d,{'result':2},'BLOCKED_DATA'))
            self.assertEqual(before,(Path(d)/'latest.json').read_bytes())
    def test_late_valid_can_publish(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertTrue(publish_latest(d,{'result':1},'LATE'))
            self.assertTrue((Path(d)/'latest.json').exists())

if __name__=='__main__': unittest.main()
