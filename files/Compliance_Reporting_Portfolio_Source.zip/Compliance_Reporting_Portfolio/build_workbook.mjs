import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Workbook, SpreadsheetFile } from '@oai/artifact-tool';
process.on('uncaughtException', e=>{console.error(e.message);process.exit(1);});
const root = path.dirname(fileURLToPath(import.meta.url));
const output = path.resolve(root, '../outputs/01a0b20a-7454-7a12-bfb3-04fafa9b3528/wren');
await fs.mkdir(output, {recursive:true});
const data = JSON.parse(await fs.readFile(path.join(root, 'portfolio/evidence/workbook_data.json'),'utf8'));
const wb = Workbook.create();
const report=wb.worksheets.add('Reporting'), pivot=wb.worksheets.add('Pivot'), cases=wb.worksheets.add('Cases'), runs=wb.worksheets.add('Runs');
const navy='#16384B', teal='#087E83', muted='#526575', blue='#1765A3', pale='#EEF5F7';
for (const s of [report,pivot,cases,runs]) {
 s.showGridLines=false;s.getRange('A1:P60').format.font={name:'Arial',size:11,color:navy};
 s.getRange('A1:P60').format.columnWidth=17;s.getRange('A1:P60').format.rowHeight=23;
 s.freezePanes.freezeRows(5);s.tabColor=teal;
}
function merge(s,r,text,fill=null,size=11,bold=false,color=navy) {
 const a=s.getRange(r);a.merge();s.getRange(r.split(':')[0]).values=[[text]];
 a.format={font:{name:'Arial',size,bold,color},wrapText:true,verticalAlignment:'center',...(fill?{fill}:{})};
}
function heading(s,r,text) {merge(s,r,text,navy,17,true,'#FFFFFF');}
function header(s,r,values) {const a=s.getRange(r);a.values=[values];a.format={fill:teal,font:{name:'Arial',size:11,bold:true,color:'#FFFFFF'},wrapText:true,verticalAlignment:'center'};a.format.rowHeight=32;}
const dt=s=>s?new Date(s.replace(' ','T')+(/[Zz]|[+-]\d\d:\d\d$/.test(s)?'':'Z')):null, end=data.rows.length+5;
heading(cases,'A1:H2','Operational case register');
merge(cases,'A3:H4','One row per case. A:H are inputs; I:O are formula-derived. Blank Closed = still open. Dates are UTC. Filters do not change headline KPIs.',pale);
header(cases,'A5:O5',['Case ID','Department','Category','Priority','Opened','Due','Closed','Dept ID','Open flag','Overdue flag','Due flag','On-time flag','Closed flag','Resolution days','Status']);
cases.getRange(`A6:H${end}`).values=data.rows.map(r=>[r.case_id,data.departments[r.department_id],r.category,r.priority,dt(r.opened_at),dt(r.due_at),dt(r.closed_at),r.department_id]);
cases.getRange(`I6:O${end}`).formulas=data.rows.map((r,i)=>{const n=i+6;return [
 `=IF(AND(E${n}<Reporting!$B$4,OR(G${n}="",G${n}>=Reporting!$B$4)),1,0)`,
 `=IF(AND(I${n}=1,F${n}<Reporting!$B$4),1,0)`, `=IF(F${n}<Reporting!$B$4,1,0)`,
 `=IF(AND(K${n}=1,G${n}<>"",G${n}<=F${n}),1,0)`, `=IF(AND(G${n}<>"",G${n}<Reporting!$B$4),1,0)`,
 `=IF(M${n}=1,G${n}-E${n},"")`, `=IF(E${n}>=Reporting!$B$4,"Outside cutoff",IF(M${n}=1,"Closed",IF(J${n}=1,"Overdue","Open - within SLA")))`];});
cases.getRange(`A6:O${end}`).format.font={name:'Arial',size:11,color:navy};cases.getRange(`A6:H${end}`).format.font.color=blue;
cases.getRange(`E6:G${end}`).setNumberFormat('dd mmm yyyy');cases.getRange(`N6:N${end}`).setNumberFormat('0.0');
cases.getRange('B:B').format.columnWidth=24;cases.getRange('C:C').format.columnWidth=23;cases.getRange('O:O').format.columnWidth=23;
cases.tables.add(`A5:O${end}`,true,'CasesData');
cases.getRange(`J6:J${end}`).conditionalFormats.add('cellIs',{operator:'equal',formula:1,format:{fill:'#FCE7DF',font:{color:'#9F3C25'}}});
const R=c=>`Cases!$${c}$6:$${c}$${end}`;
heading(report,'A1:H2','Compliance reporting and case backlog');
merge(report,'A3:H3','FICTIONAL DATA / 29 Jun - 20 Sep 2026 / Prepared by Erochukwu Amajoyi',null,11,false,muted);
report.getRange('A4').values=[['Cutoff (exclusive)']];report.getRange('B4').values=[[dt('2026-09-21 00:00:00')]];
report.getRange('B4').setNumberFormat('dd mmm yyyy');report.getRange('B4').format={fill:pale,font:{color:navy,bold:true}};
merge(report,'C4:H4','Midnight UTC. Snapshot includes all activity before this timestamp.',null,11,false,muted);
for(const [label,value,name,formula] of [
 ['A6:B6','A7:B8','Total cases',`=COUNTIF(${R('E')},"<"&$B$4)`],['C6:D6','C7:D8','Open backlog',`=SUM(${R('I')})`],
 ['E6:F6','E7:F8','Overdue open',`=SUM(${R('J')})`],['G6:H6','G7:H8','On-time due cohort',`=IF(SUM(${R('K')})=0,"n.a.",SUM(${R('L')})/SUM(${R('K')}))`]
 ]){merge(report,label,name,navy,11,true,'#FFFFFF');merge(report,value,'',pale,23,true);report.getRange(value.split(':')[0]).formulas=[[formula]];}
for(const c of ['A7','C7','E7'])report.getRange(c).setNumberFormat('#,##0');
report.getRange('G7').setNumberFormat('0.0%');
merge(report,'A10:H11','Due cohort: 365 on time / 1,076 due. Open due cases remain in the denominator. Mean resolution: 10.2 calendar days across 934 closed cases. All counts are illustrative, not Wren results.',pale);
report.getRange('A10').formulas=[[`="Due cohort: "&SUM(${R('L')})&" on time / "&SUM(${R('K')})&" due. Open due cases remain in the denominator. Mean resolution: "&TEXT(AVERAGE(${R('N')}),"0.0")&" days across "&SUM(${R('M')})&" closed cases. Illustrative data, not Wren results."`]];
header(report,'A13:D13',['Department','Cases','Open','Overdue']);const depts=Object.values(data.departments);
report.getRange('A14:A16').values=depts.map(d=>[d]);
report.getRange('B14:D16').formulas=depts.map((d,i)=>{const n=14+i;return [`=COUNTIFS(${R('B')},A${n},${R('E')},"<"&$B$4)`,`=SUMIFS(${R('I')},${R('B')},A${n})`,`=SUMIFS(${R('J')},${R('B')},A${n})`];});
report.getRange('A17:D17').values=[['Total',null,null,null]];report.getRange('B17:D17').formulas=[['=SUM(B14:B16)','=SUM(C14:C16)','=SUM(D14:D16)']];report.getRange('A17:D17').format.fill=pale;
merge(report,'A19:D21','Review the oldest overdue cases first; compare workload and resolution by department before changing targets. The fixture intentionally slows some Warehouse cases; this is not a causal finding.',pale);
const weeks=data.query_results.period_summary.filter(r=>r.grain==='weekly');
header(report,'A23:D23',['Week starting','Opened','Closed','Closing backlog']);
report.getRange('A24:A35').values=weeks.map(r=>[dt(r.period_start)]);report.getRange('A24:A35').setNumberFormat('dd mmm');
report.getRange('B24:D35').formulas=weeks.map((r,i)=>{const n=24+i;return [
 `=COUNTIFS(${R('E')},">="&A${n},${R('E')},"<"&A${n}+7)`, `=COUNTIFS(${R('G')},">="&A${n},${R('G')},"<"&A${n}+7)`,
 `=COUNTIF(${R('E')},"<"&A${n}+7)-COUNTIFS(${R('G')},">=1",${R('G')},"<"&A${n}+7)`];});
pivot.getRange('D20:E32').values=[['Chart source / week','Closing backlog'],...weeks.map(r=>[new Date(r.period_start).toLocaleDateString('en-GB',{day:'2-digit',month:'short',timeZone:'UTC'}),null])];
pivot.getRange('E21:E32').formulas=weeks.map((r,i)=>[`=Reporting!D${24+i}`]);
const chart=report.charts.add('line',pivot.getRange('D20:E32'));
chart.title='Weekly closing backlog';chart.titleTextStyle.typeface='Arial';chart.titleTextStyle.fontSize=16;
chart.setPosition('E13','H30');chart.hasLegend=false;chart.series.items[0].fill=teal;chart.series.items[0].line={fill:teal,style:'solid',width:2};
chart.xAxis={axisType:'textAxis',textStyle:{typeface:'Arial',fontSize:11}};
chart.xAxis.title.text='Week starting';
chart.yAxis={numberFormatCode:'0',numberFormatSourceLinked:false,textStyle:{typeface:'Arial',fontSize:11}};
merge(report,'E31:H33','Backlog is a point-in-time stock. Do not sum weekly or monthly backlog balances.',pale);
header(report,'A38:E38',['Month / coverage','Opened','Closed','Closing backlog','Partial month?']);
const months=data.query_results.period_summary.filter(r=>r.grain==='monthly');
report.getRange('A39:E42').values=months.map((r,i)=>[['Jun 29-30','Jul 01-31','Aug 01-31','Sep 01-20'][i],Number(r.opened_cases),Number(r.closed_cases),Number(r.closing_backlog),Number(r.partial_period)?'Yes':'No']);
report.getRange('E39:E42').format.horizontalAlignment='center';
merge(report,'A44:E46','Monthly figures are validated MySQL outputs. June and September are partial months and should not be compared directly with full months. Weekly rows are complete seven-day periods.',pale);
merge(report,'A48:H50','Refresh: rerun the Python validation/query pipeline, then rebuild this workbook. Tables support filtering; native Pivot is on its own tab. This file is not connected to live systems and has no deployed scheduler or email delivery.',null,11,false,muted);
report.getRange('A:A').format.columnWidth=25;report.getRange('A14:A16').format.wrapText=true;report.getRange('A14:D16').format.rowHeight=31;
heading(pivot,'A1:F2','Case volume by department');
merge(pivot,'A3:F4','Counts of all 1,200 cases. Use the PivotTable field list to rearrange Department and Category in desktop Excel. The current layout counts Case ID by Department.',pale);
header(pivot,'A6:B6',['Department','Case count']);
pivot.getRange('A7:B10').values=[...depts.map(d=>[d,data.rows.filter(r=>data.departments[r.department_id]===d).length]),['Grand Total',data.rows.length]];
pivot.getRange('A:A').format.columnWidth=27;pivot.getRange('A10:B10').format={fill:pale,font:{bold:true}};
merge(pivot,'D6:G11','Source: Cases!A5:C'+end+'. Native Pivot cache contains Department, Category and Case ID. After source edits, Refresh the PivotTable. If source row count changes, rebuild this workbook to extend the cache range.',pale);
merge(pivot,'A14:G17','Refresh after source edits. The PivotTable counts all cases in the extract; dashboard status measures use the snapshot cutoff. Calculation and cache checks are documented in the project README. Native Excel Desktop refresh remains unverified.',null,11,false,muted);
heading(runs,'A1:J2','Report freshness and publication controls');
merge(runs,'A3:J4','Four controlled tests executed on 27 Sep 2026. Evaluation times simulate source freshness and deadlines; these are not historical scheduled runs. Blocked runs preserve the latest successful report.',pale);
header(runs,'A6:J6',['Scenario','Status','Input rows','Accepted','Issues','Age (min)','Runtime (ms)','Published?','MySQL','Evaluated UTC']);
runs.getRange('A7:J10').values=data.runs.map(r=>[r.scenario,r.status,r.input_rows,r.accepted_rows,r.issue_count,r.source_age_minutes,r.duration_ms,r.published?'Yes':'No',r.mysql_version||'Not queried',dt(r.scenario_evaluation_utc)]);
runs.getRange('B:B').format.columnWidth=24;runs.getRange('J:J').format.columnWidth=24;runs.getRange('J7:J10').setNumberFormat('dd mmm hh:mm:ss');runs.getRange('G7:G10').setNumberFormat('0.0');
runs.getRange('H7:H10').format.horizontalAlignment='center';
runs.getRange('B7:B10').conditionalFormats.add('containsText',{text:'BLOCKED',format:{fill:'#FCE7DF',font:{color:'#9F3C25'}}});
runs.getRange('B7:B10').conditionalFormats.add('containsText',{text:'LATE',format:{fill:'#FFF2CC',font:{color:'#795E13'}}});
merge(runs,'A13:J15','Data checks: unique keys, valid departments/categories/priorities, parseable dates, chronological order and snapshot boundaries. The dirty fixture has 1,201 rows; both duplicate occurrences are rejected, leaving 1,194 acceptable rows. Any data issue blocks publication.',pale);
merge(runs,'A17:J19','Freshness: source age must be 0-30 minutes. Valid but late runs are labelled LATE and may publish; invalid or stale runs cannot. Source SHA-256 and real execution timestamps are retained in the evidence files. All headline, department and 100 period-row results were reconciled independently.',pale);
merge(runs,'A21:J23','Production next steps: agree metric definitions with stakeholders, connect an authorised source, configure credentials and scheduling, then test alert delivery, retries and ownership. No scheduler, email transport or production connection is installed in this demonstration.',null,11,false,muted);
wb.recalculate();const get=(s,r)=>s.getRange(r).values[0][0];
for(const [cell,num] of [['A7',1200],['C7',266],['E7',157],['G7',365/1076]])if(typeof get(report,cell)!=='number'||Math.abs(get(report,cell)-num)>1e-8)throw Error(`${cell}: ${get(report,cell)} != ${num}`);
for(let i=0;i<weeks.length;i++)for(const [c,key] of [['B','opened_cases'],['C','closed_cases'],['D','closing_backlog']])if(get(report,`${c}${i+24}`)!==Number(weeks[i][key]))throw Error('Weekly reconciliation '+i+key);
// Recalculation after an input change is checked independently in LibreOffice.
const errors=[];
for(const [s,r] of [[report,'A1:H50'],[cases,`A5:O${end}`],[pivot,'A1:G17'],[runs,'A1:J23']])for(const row of s.getRange(r).values)for(const v of row)if(typeof v==='string'&&/^#(REF!|VALUE!|DIV\/0!|NAME\?|N\/A|NUM!|SPILL!|CALC!)/.test(v))errors.push(v);
if(errors.length)throw Error(JSON.stringify(errors.slice(0,10)));
console.log((await wb.inspect({kind:'region',sheetId:'Reporting',range:'A6:H17',maxChars:4000,tableMaxRows:12,tableMaxCols:8})).ndjson);
const file=await SpreadsheetFile.exportXlsx(wb);await file.save(path.join(output,'Compliance_Reporting_Workbook.xlsx'));
for(const [s,r] of [['Reporting','A1:H50'],['Pivot','A1:G33'],['Cases','A1:H16'],['Runs','A1:J23']]){const img=await wb.render({sheetName:s,range:r,scale:1.3,format:'png'});await fs.writeFile(path.join(root,'qa',`${s}.png`),new Uint8Array(await img.arrayBuffer()));}
await fs.writeFile(path.join(root,'qa/workbook_checks.json'),JSON.stringify({headline:'PASS',weekly_rows:12,modified_input:'See independent LibreOffice check',formula_errors:errors,native_excel_refresh:'NOT TESTED'},null,2));
console.log(path.join(output,'Compliance_Reporting_Workbook.xlsx'));
