"""Add only the unsupported native Pivot package; validate via independent readers.

All sheets, values, formulas, formatting and charts are authored by artifact-tool.
This standard-library OOXML extension supplies its missing reliable Pivot export.
"""
from pathlib import Path
import json
import zipfile
import xml.etree.ElementTree as E
import subprocess
from datetime import datetime
from openpyxl import load_workbook  # Read-only QA: never used to author/save.

ROOT=Path(__file__).resolve().parent
OUT=ROOT.parent/'outputs/01a0b20a-7454-7a12-bfb3-04fafa9b3528/wren'
FILE=OUT/'Compliance_Reporting_Workbook.xlsx'
S='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
P='http://schemas.openxmlformats.org/package/2006/relationships'
C='http://schemas.openxmlformats.org/package/2006/content-types'
E.register_namespace('',S);E.register_namespace('r',R)
def el(tag,**attrs):return E.Element('{'+S+'}'+tag,{k:str(v) for k,v in attrs.items()})
def sub(parent,tag,**attrs):node=el(tag,**attrs);parent.append(node);return node
def xml(node):return E.tostring(node,encoding='utf-8',xml_declaration=True)
def relation(rid,kind,target):return E.Element('{'+P+'}Relationship',Id=rid,Type=R+'/'+kind,Target=target)
with zipfile.ZipFile(FILE) as z: parts={n:z.read(n) for n in z.namelist()}
d=json.loads((ROOT/'portfolio/evidence/workbook_data.json').read_text())
depts=list(d['departments'].values());categories=sorted({r['category'] for r in d['rows']})
shared=[[r['case_id'] for r in d['rows']],depts,categories]
cache=el('pivotCacheDefinition',saveData=1,refreshOnLoad=0,recordCount=len(d['rows']),createdVersion=6,refreshedVersion=6,minRefreshableVersion=3)
cache.set('{'+R+'}id','rId1')
source=sub(cache,'cacheSource',type='worksheet');sub(source,'worksheetSource',ref=f'A5:C{len(d["rows"])+5}',sheet='Cases')
fields=sub(cache,'cacheFields',count=3)
for name,vals in zip(['Case ID','Department','Category'],shared):
    f=sub(fields,'cacheField',name=name,numFmtId=0);items=sub(f,'sharedItems',count=len(vals),containsString=1,containsNumber=0,containsBlank=0,containsSemiMixedTypes=0)
    for val in vals:sub(items,'s',v=val)
records=el('pivotCacheRecords',count=len(d['rows']))
for i,r in enumerate(d['rows']):
    rec=sub(records,'r')
    for val in [i,depts.index(d['departments'][str(r['department_id'])]),categories.index(r['category'])]:sub(rec,'x',v=val)
piv=el('pivotTableDefinition',name='CasesByDepartment',cacheId=1,dataCaption='Case count',grandTotalCaption='Grand Total',rowGrandTotals=1,colGrandTotals=1,compact=0,compactData=0,gridDropZones=0,outline=1,outlineData=1,createdVersion=6,updatedVersion=6,minRefreshableVersion=3,useAutoFormatting=1,itemPrintTitles=1)
sub(piv,'location',ref='A6:B10',firstHeaderRow=1,firstDataRow=1,firstDataCol=1)
pf=sub(piv,'pivotFields',count=3)
sub(pf,'pivotField',dataField=1,showAll=0)
rowfield=sub(pf,'pivotField',axis='axisRow',showAll=0,defaultSubtotal=0,compact=0,outline=0)
items=sub(rowfield,'items',count=4)
for i in range(3):sub(items,'item',x=i)
sub(items,'item',t='default')
unused=sub(pf,'pivotField',showAll=0)
items=sub(unused,'items',count=len(categories))
for i in range(len(categories)):sub(items,'item',x=i)
rf=sub(piv,'rowFields',count=1);sub(rf,'field',x=1)
ri=sub(piv,'rowItems',count=4)
for i in range(3):sub(sub(ri,'i'),'x',v=i)
sub(sub(ri,'i',t='grand'),'x')
ci=sub(piv,'colItems',count=1);sub(sub(ci,'i'),'x')
df=sub(piv,'dataFields',count=1);sub(df,'dataField',name='Case count',fld=0,subtotal='count',baseField=0,baseItem=0,numFmtId=0)
sub(piv,'pivotTableStyleInfo',name='PivotStyleMedium9',showRowHeaders=1,showColHeaders=1,showRowStripes=1,showColStripes=0,showLastColumn=1)
parts['xl/pivotCache/pivotCacheDefinition1.xml']=xml(cache)
parts['xl/pivotCache/pivotCacheRecords1.xml']=xml(records)
parts['xl/pivotTables/pivotTable1.xml']=xml(piv)
for name,kind,target in [('xl/pivotCache/_rels/pivotCacheDefinition1.xml.rels','pivotCacheRecords','pivotCacheRecords1.xml'),('xl/pivotTables/_rels/pivotTable1.xml.rels','pivotCacheDefinition','../pivotCache/pivotCacheDefinition1.xml')]:
    rel=E.Element('{'+P+'}Relationships');rel.append(relation('rId1',kind,target));parts[name]=xml(rel)
book=E.fromstring(parts['xl/workbook.xml']);pc=el('pivotCaches');sub(pc,'pivotCache',cacheId=1).set('{'+R+'}id','rIdNativePivotCache');book.append(pc)
calc=book.find('{'+S+'}calcPr')
if calc is not None:calc.set('fullCalcOnLoad','1');calc.set('forceFullCalc','1');calc.set('calcMode','auto')
parts['xl/workbook.xml']=xml(book)
rels=E.fromstring(parts['xl/_rels/workbook.xml.rels']);rels.append(relation('rIdNativePivotCache','pivotCacheDefinition','pivotCache/pivotCacheDefinition1.xml'));parts['xl/_rels/workbook.xml.rels']=xml(rels)
# Pivot is second worksheet, confirmed by the authoring builder's fixed order.
sheet=E.fromstring(parts['xl/worksheets/sheet2.xml']);pp=sub(sheet,'pivotParts',count=1);sub(pp,'pivotPart').set('{'+R+'}id','rIdNativePivot')
parts['xl/worksheets/sheet2.xml']=xml(sheet)
key='xl/worksheets/_rels/sheet2.xml.rels';rels=E.fromstring(parts[key]) if key in parts else E.Element('{'+P+'}Relationships')
rels.append(relation('rIdNativePivot','pivotTable','../pivotTables/pivotTable1.xml'));parts[key]=xml(rels)
types=E.fromstring(parts['[Content_Types].xml'])
for name,kind in [('pivotCache/pivotCacheDefinition1.xml','pivotCacheDefinition'),('pivotCache/pivotCacheRecords1.xml','pivotCacheRecords'),('pivotTables/pivotTable1.xml','pivotTable')]:
    E.SubElement(types,'{'+C+'}Override',PartName='/xl/'+name,ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.'+kind+'+xml')
parts['[Content_Types].xml']=xml(types)
# Supply the chart's missing export caches without changing its live cell bindings.
CN='http://schemas.openxmlformats.org/drawingml/2006/chart'
for name in list(parts):
    if '/charts/' not in name or not name.endswith('.xml'):continue
    chart=E.fromstring(parts[name])
    weeks=[r for r in d['query_results']['period_summary'] if r['grain']=='weekly']
    for tag,vals in [('strCache',[datetime.fromisoformat(r['period_start']).strftime('%d %b') for r in weeks]),('numCache',[r['closing_backlog'] for r in weeks])]:
        cache=chart.find('.//{'+CN+'}'+tag)
        for child in list(cache):
            if child.tag!='{'+CN+'}formatCode':cache.remove(child)
        E.SubElement(cache,'{'+CN+'}ptCount',val=str(len(vals)))
        for i,val in enumerate(vals):E.SubElement(E.SubElement(cache,'{'+CN+'}pt',idx=str(i)),'{'+CN+'}v').text=str(val)
    parts[name]=xml(chart)
with zipfile.ZipFile(FILE,'w',zipfile.ZIP_DEFLATED) as z:
    for name,content in parts.items():z.writestr(name,content)
check=load_workbook(FILE,data_only=False)
assert len(check['Pivot']._pivots)==1
p=check['Pivot']._pivots[0]
assert p.cache.recordCount==1200 and p.cache.cacheSource.worksheetSource.ref=='A5:C1205'
assert len(p.cache.records.r)==1200
assert len(check['Reporting']._charts)==1
assert len(check['Cases'].tables)==1
values=load_workbook(FILE,data_only=True)
assert [values['Reporting'][c].value for c in ['A7','C7','E7']]==[1200,266,157]
print('Native Pivot, 1200 cache records, chart, table and KPI caches validated.')
# Recalculate the original and an input-edited scratch copy with LibreOffice.
q=ROOT/'qa';(q/'input').mkdir(exist_ok=True);(q/'recalculated').mkdir(exist_ok=True)
(q/'input/original.xlsx').write_bytes(FILE.read_bytes())
changed=dict(parts);cs=E.fromstring(changed['xl/worksheets/sheet3.xml'])
row=next(i+6 for i,r in enumerate(d['rows']) if not r['closed_at'])
cell=cs.find(f'.//{{{S}}}c[@r="G{row}"]')
if cell is None:
    rr=cs.find(f'.//{{{S}}}row[@r="{row}"]');cell=sub(rr,'c',r=f'G{row}')
for child in list(cell):cell.remove(child)
cell.attrib.pop('t',None);sub(cell,'v').text=str((datetime(2026,9,20,23)-datetime(1899,12,30)).total_seconds()/86400)
changed['xl/worksheets/sheet3.xml']=xml(cs)
with zipfile.ZipFile(q/'input/changed.xlsx','w',zipfile.ZIP_DEFLATED) as z:
    for name,content in changed.items():
        if name.startswith('xl/worksheets/sheet') and name.endswith('.xml'):
            tree=E.fromstring(content)
            for c in tree.iter('{'+S+'}c'):
                if c.find('{'+S+'}f') is not None:
                    v=c.find('{'+S+'}v')
                    if v is not None:c.remove(v)
            content=xml(tree)
        z.writestr(name,content)
soffice='/Users/ero/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/override/soffice'
proc=subprocess.run([soffice,'-env:UserInstallation=file:///private/tmp/ero-wren-lo-qa','--headless','--convert-to','xlsx','--outdir',str(q/'recalculated'),str(q/'input/original.xlsx'),str(q/'input/changed.xlsx')],capture_output=True,text=True,timeout=90)
print(proc.stdout,proc.stderr[-2000:]);proc.check_returncode()
recalc=load_workbook(q/'recalculated/original.xlsx',data_only=True)
edit=load_workbook(q/'recalculated/changed.xlsx',data_only=True)
assert [recalc['Reporting'][c].value for c in ['A7','C7','E7']]==[1200,266,157]
assert edit['Reporting']['C7'].value==265, edit['Reporting']['C7'].value
for ws in recalc:
    assert not [(c.coordinate,c.value) for row in ws for c in row if c.data_type=='e']
assert len(load_workbook(q/'recalculated/original.xlsx')['Pivot']._pivots)==1
(q/'independent_workbook_checks.json').write_text(json.dumps({'reader_pivot_records':1200,'libreoffice_recalculation':'PASS','input_change_backlog':[266,265],'formula_errors':0,'native_excel_refresh':'NOT TESTED'},indent=2))
print('LibreOffice recalculation, no formula errors, native Pivot retained, input change 266 -> 265 PASS.')
# A one-page print copy permits visual QA of the native chart in another renderer.
printparts=dict(parts)
book=E.fromstring(printparts['xl/workbook.xml'])
names=book.find('{'+S+'}definedNames')
if names is None:
    names=el('definedNames');book.insert(list(book).index(book.find('{'+S+'}sheets'))+1,names)
sub(names,'definedName',name='_xlnm.Print_Area',localSheetId=0).text="'Reporting'!$A$1:$H$50"
printparts['xl/workbook.xml']=xml(book)
sheet=E.fromstring(printparts['xl/worksheets/sheet1.xml'])
pr=sheet.find('{'+S+'}sheetPr')
if pr is None:pr=el('sheetPr');sheet.insert(0,pr)
sub(pr,'pageSetUpPr',fitToPage=1)
setup=sheet.find('{'+S+'}pageSetup')
if setup is None:setup=sub(sheet,'pageSetup')
setup.set('paperSize','9');setup.set('fitToWidth','1');setup.set('fitToHeight','1');setup.set('orientation','portrait')
printparts['xl/worksheets/sheet1.xml']=xml(sheet)
with zipfile.ZipFile(q/'input/print.xlsx','w',zipfile.ZIP_DEFLATED) as z:
    for name,content in printparts.items():z.writestr(name,content)
proc=subprocess.run([soffice,'-env:UserInstallation=file:///private/tmp/ero-wren-lo-qa','--headless','--convert-to','pdf:calc_pdf_Export:{"PageRange":{"type":"string","value":"1"}}','--outdir',str(q),str(q/'input/print.xlsx')],capture_output=True,text=True,timeout=90)
print(proc.stdout,proc.stderr[-1000:]);proc.check_returncode()
