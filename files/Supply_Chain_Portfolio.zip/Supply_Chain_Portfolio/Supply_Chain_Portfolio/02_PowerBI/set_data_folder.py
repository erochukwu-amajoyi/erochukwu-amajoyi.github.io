"""Run after moving the portfolio, before opening Power BI."""
import json
from pathlib import Path
p=Path(__file__).resolve().parent/'Supply.SemanticModel/model.bim'
m=json.loads(p.read_text())
m['model']['expressions'][0]['expression']=json.dumps((p.parents[2]/'data/clean').as_posix())+' meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]'
p.write_text(json.dumps(m,indent=2),encoding='utf-8')
print('DataFolder updated. Open Supply.pbip and Refresh.')
