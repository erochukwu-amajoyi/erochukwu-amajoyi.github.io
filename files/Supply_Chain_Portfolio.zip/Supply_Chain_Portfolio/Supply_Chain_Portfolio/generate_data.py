"""Deterministic fictional kitchen-products supply chain. Python standard library only."""
import csv, json, random
from pathlib import Path
from datetime import date, timedelta

ROOT = Path(__file__).resolve().parent
AS_OF = date(2026, 9, 21)

def write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

def generate():
    rng = random.Random(42)
    suppliers = [dict(SupplierID=f'S{i:03}', Supplier=f'{n} Components', Country=c, LeadDays=l)
        for i,(n,c,l) in enumerate([('Alder','UK',7),('Birch','Germany',12),('Cedar','Poland',16),('Elm','Italy',18),('Maple','Turkey',25),('Oak','Portugal',14)],1)]
    items=[]; inventory=[]; orders=[]; bom=[]
    cats=['Sinks','Taps','Hoods','Accessories']
    for i in range(1,81):
        s=suppliers[(i-1)%6]; cost=round(rng.uniform(12,240),2); demand=rng.randint(60,1200)
        item=dict(ItemID=f'K{i:04}', Category=cats[(i-1)%4], SupplierID=s['SupplierID'], Unit='EA', UnitCost=cost, LeadDays=s['LeadDays'])
        items.append(item)
        inventory.append(dict(ItemID=item['ItemID'], OnHand=rng.randint(0,max(1,int(demand*.8))), Allocated=rng.randint(0,20), OnOrder=rng.randint(0,80), Demand90=demand, AvgStock90=round(demand*rng.uniform(.15,.55),1)))
    for i in range(1,1501):
        item=rng.choice(items); placed=date(2026,1,1)+timedelta(days=rng.randrange(248)); due=placed+timedelta(days=item['LeadDays']); qty=rng.randint(10,180)
        # A deliberately weaker fictional supplier gives a business question to investigate.
        delay=rng.choice([-3,-1,0,0,1,3,7,12])+(4 if item['SupplierID']=='S005' else 0)
        received=due+timedelta(days=delay); closed=received<=AS_OF
        got=qty if rng.random()>.08 else int(qty*.85)
        orders.append(dict(OrderLine=f'PO{i:06}-10',ItemID=item['ItemID'],SupplierID=item['SupplierID'],OrderDate=placed.isoformat(),DueDate=due.isoformat(),ReceiptDate=received.isoformat() if closed else '',OrderedQty=qty,ReceivedQty=got if closed else 0,UnitCost=item['UnitCost']))
    for i in range(1,21):
        for j in range(3): bom.append(dict(ParentID=f'KIT{i:03}', ComponentID=f'K{(i*3+j)%80+1:04}', Quantity=j+1, Unit='EA'))
    for name,rows in [('suppliers',suppliers),('items',items),('inventory',inventory),('orders',orders),('bom',bom)]: write_csv(ROOT/'data'/'clean'/f'{name}.csv',rows)
    dirty=[dict(r) for r in orders]; dirty.append(dict(dirty[0])); dirty[10]['ItemID']='UNKNOWN'; dirty[20]['OrderedQty']=-4; dirty[30]['ReceiptDate']='not-a-date'; dirty[40]['SupplierID']='S999'
    write_csv(ROOT/'data'/'raw'/'orders.csv',dirty)
    dirty_bom=[dict(r) for r in bom]; dirty_bom.append(dict(dirty_bom[0])); dirty_bom[4]['ComponentID']='MISSING'; dirty_bom[8]['Quantity']=0
    write_csv(ROOT/'data'/'raw'/'bom.csv',dirty_bom)
    (ROOT/'data'/'metadata.json').write_text(json.dumps(dict(as_of=AS_OF.isoformat(),seed=42,source='Entirely synthetic; no Franke or SAP system data',inventory_period='Trailing 90 days ending 2026-09-21',orders_period='Order dates 2026-01-01 to 2026-09-05'),indent=2))
    print('Generated 80 items, 6 suppliers, 1500 order lines and 60 BOM components.')

if __name__=='__main__': generate()
