# Data dictionary

All CSVs use UTF-8, comma separators, a header row and ISO dates. IDs are text. Blank ReceiptDate means no receipt recorded by the fixed snapshot date, with ReceivedQty = 0.

| File | Grain and key | Fields and units |
|---|---|---|
| suppliers.csv | One row per SupplierID | Supplier (fictional name), Country, LeadDays (contractual calendar days) |
| items.csv | One row per ItemID | Category, SupplierID (default supplier), Unit (EA), UnitCost (GBP per unit), LeadDays (calendar days) |
| inventory.csv | One row per ItemID at 21 Sep 2026 | OnHand, Allocated, OnOrder (units); Demand90 (fulfilled units over trailing 90 days); AvgStock90 (average units over same period) |
| orders.csv | One row per OrderLine | ItemID, SupplierID, OrderDate, DueDate, ReceiptDate; OrderedQty and ReceivedQty (units); UnitCost (GBP per unit) |
| bom.csv | One row per ParentID + ComponentID | Quantity (component units per parent kit); Unit (EA). KIT identifiers are assemblies and component ItemIDs join to items. |
| dates.csv | One row per Date in 2026 | Month (YYYY-MM), MonthNumber (1–12). Used for due-date reporting. |

`clean` contains known-good generated fixtures. `raw` contains deliberately injected errors for the quality-control demonstration. They are not two independent ERP feeds and should not be appended together.

Inventory OnOrder is an independent planning input. It is not reconciled to open purchase-order lines. No goods-movement ledger, cancellations, currencies other than GBP, multi-delivery lines, supplier holidays or real customer information is included.
