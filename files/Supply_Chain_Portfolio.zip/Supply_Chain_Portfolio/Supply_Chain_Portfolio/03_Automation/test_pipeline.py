import unittest
import tempfile,json
from pathlib import Path
from datetime import date
from pipeline import validate, metrics, run, ROOT

class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.item=[dict(ItemID='A',SupplierID='S',Unit='EA')]; self.sup=[dict(SupplierID='S')]
        self.row=dict(OrderLine='1',ItemID='A',SupplierID='S',OrderDate='2026-01-01',DueDate='2026-01-10',ReceiptDate='2026-01-10',OrderedQty='10',ReceivedQty='10',UnitCost='2')
    def test_ontime_boundary(self): self.assertEqual(metrics([self.row],date(2026,1,10))['otif_rate'],1)
    def test_overdue_open_in_denominator(self):
        r=dict(self.row,ReceiptDate='',ReceivedQty='0'); m=metrics([r],date(2026,1,11)); self.assertEqual(m['otif_rate'],0); self.assertEqual(m['overdue_open_lines'],1)
    def test_future_due_excluded(self): self.assertIsNone(metrics([self.row],date(2026,1,9))['otif_rate'])
    def test_partial_receipt_not_otif(self): self.assertEqual(metrics([dict(self.row,ReceivedQty='9')],date(2026,1,10))['otif_rate'],0)
    def test_duplicate_rejected(self): self.assertEqual(len(validate([self.row,self.row],self.item,self.sup,[])[0]),1)
    def test_bad_date_rejected(self): self.assertEqual(len(validate([dict(self.row,ReceiptDate='bad')],self.item,self.sup,[])[0]),0)
    def test_unknown_item(self): self.assertTrue(validate([dict(self.row,ItemID='X')],self.item,self.sup,[])[1])
    def test_bom_cycle(self): self.assertIn('bom_cycle',[i['rule'] for i in validate([],self.item,self.sup,[dict(ParentID='KIT1',ComponentID='KIT1',Quantity='1',Unit='EA')])[1]])
    def test_zero_bom(self): self.assertIn('nonpositive_bom_quantity',[i['rule'] for i in validate([],self.item,self.sup,[dict(ParentID='KIT1',ComponentID='A',Quantity='0',Unit='EA')])[1]])
    def test_future_order_excluded(self): self.assertEqual(metrics([self.row],date(2025,12,31))['order_lines'],0)
    def test_duplicate_master_blocks(self): self.assertIn('missing_or_duplicate_master_key',[i['rule'] for i in validate([self.row],self.item*2,self.sup,[])[1]])
    def test_failed_run_preserves_latest_and_rerun_is_idempotent(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp);asof=date(2026,9,21)
            self.assertEqual(run(ROOT/'data/clean',out,asof),0)
            latest=(out/'latest.json').read_bytes()
            self.assertEqual(run(ROOT/'data/clean',out,asof),0)
            self.assertEqual(latest,(out/'latest.json').read_bytes())
            self.assertEqual(run(ROOT/'data/raw',out,asof),2)
            self.assertEqual(latest,(out/'latest.json').read_bytes())
if __name__=='__main__': unittest.main()
